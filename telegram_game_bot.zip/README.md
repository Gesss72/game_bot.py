# Telegram Game Bot

Bot multiplayer per sfide online in 3 step su Telegram.

## ✅ Funzionalità
- Scelte su 3 step: Fuoco/Acqua, Pari/Dispari, Guerriero/Mago/Ladro
- Calcolo automatico dei punteggi
- Matchmaking automatico tra utenti
- Statistiche tra giocatori (/stats)
- Timer automatico per ogni fase

## 📦 Installazione
1. Clona questo repo o caricalo su [Render](https://render.com)
2. Aggiungi variabile d’ambiente `TELEGRAM_TOKEN` con il token del tuo bot
3. Start command: `python game_bot.py`

## 🧾 Requisiti
```
python-telegram-bot==20.7
```

## ✨ Comandi disponibili
- `/start`: Avvia una partita
- `/stats`: Mostra le statistiche contro altri giocatori